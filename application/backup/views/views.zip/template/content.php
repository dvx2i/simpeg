<div class="wrapper  row-offcanvas-left" id="sidebarleft">
    
    
    <?= $content ?>
</div>
