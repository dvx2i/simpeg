<div class="content-wrapper">               

    <section class="content-header">
        <?php echo $this->session->flashdata('message'); ?>
        <h1>
            List Eselon
        </h1>
    </section>


    <section class="content">
        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#modal-add">Tambah Eselon</a>
        <br />
        <br />
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                    </div>
                    <div class="box-body table-responsive">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode</th>
                                    <th>Nama</th>
                                    <th>Golru Awal</th>
                                    <th>Golru Akhir</th>
                                    <th>Tunjangan</th>
                                    <th>BUP</th>
                                    <th>Administrator</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($result->result() as $value) {
                                    ?>
                                    <tr>
                                        <td><?= $no ?></td>
                                        <td><?= $value->eselon_kode ?></td>
                                        <td><?= $value->eselon_nama ?></td>
                                        <td><?= $value->eselon_pangkat_golongan_awal_nama ?></td>
                                        <td><?= $value->eselon_pangkat_golongan_akhir_nama ?></td>
                                        <td><?= $value->eselon_tunjangan ?></td>
                                        <td><?= $value->eselon_usia_pensiun ?></td>
                                        <td>
                                            <a href="#" class="btn btn-warning btn-sm" type="button" onclick="edit('<?= $value->eselon_kode ?>', '<?= $value->eselon_nama ?>','<?= $value->eselon_pangkat_golongan_awal ?>', '<?= $value->eselon_pangkat_golongan_akhir ?>', '<?= $value->eselon_tunjangan ?>', '<?= $value->eselon_usia_pensiun ?>')" data-toggle="modal" data-target="#modal-update"><i class="fa fa-edit"></i></a>
                                            <a href="<?= site_url('referensi/eselon/delete/' . $value->eselon_kode) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin menghapus data.?')"><i class="fa fa-trash-o fa-fw"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                    $no++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<div class="modal fade" id="modal-add">
    <div class="modal-dialog">
        <div class="modal-content">
            <form role="form" action="<?= site_url('referensi/eselon/add') ?>" method="post">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Tambah Eselon</h4>
                </div>
                <div class="modal-body">

                    <div class="form-group">
                        <label>Kode</label>
                        <input class="form-control" value="" name="kode" id="" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Nama</label>
                        <input class="form-control" value="" name="nama" id="" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Golru Awal</label>
                        <select class="form-control select2" style="width: 100%;" name="eselon_pangkat_golongan_awal" id="" autocomplete="off">
                            <?php
                            echo '<option value="">-- Pilih --</option>';
                            foreach ($pangkat_golongan->result() as $value) {
                                echo '<option value="' . $value->pangkat_golongan_kode . '">' . $value->pangkat_golongan_text . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Golru Akhir</label>
                        <select class="form-control select2" style="width: 100%;" name="eselon_pangkat_golongan_akhir" id="" autocomplete="off">
                            <?php
                            echo '<option value="">-- Pilih --</option>';
                            foreach ($pangkat_golongan->result() as $value) {
                                echo '<option value="' . $value->pangkat_golongan_kode . '">' . $value->pangkat_golongan_text . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tunjangan Jabatan</label>
                        <input type="number" maxlength="8" step="1" class="form-control" value="" name="eselon_tunjangan" id="" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Batas Usia Pensiun</label>
                        <input type="number" maxlength="2" step="1" class="form-control" value="" name="eselon_usia_pensiun" id="" autocomplete="off">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-update">
    <div class="modal-dialog">
        <div class="modal-content">
            <form role="form" action="<?= site_url('referensi/eselon/update') ?>" method="post">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Edit Eselon</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" value="" name="id" id="edit_id">
                    <div class="form-group">
                        <label>Kode</label>
                        <input class="form-control" value="" name="kode" id="edit_kode" readonly="true" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Nama</label>
                        <input class="form-control" value="" name="nama" id="edit_nama" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Golru Awal</label>
                        <select class="form-control select2" style="width: 100%;" name="eselon_pangkat_golongan_awal" id="edit_awal" autocomplete="off">
                            <?php
                                                        echo '<option value="">-- Pilih --</option>';
                            foreach ($pangkat_golongan->result() as $value) {
                                echo '<option value="' . $value->pangkat_golongan_kode . '">' . $value->pangkat_golongan_text . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Golru Akhir</label>
                        <select class="form-control select2" style="width: 100%;" name="eselon_pangkat_golongan_akhir" id="edit_akhir" autocomplete="off">
                            <?php
                                                        echo '<option value="">-- Pilih --</option>';
                            foreach ($pangkat_golongan->result() as $value) {
                                echo '<option value="' . $value->pangkat_golongan_kode . '">' . $value->pangkat_golongan_text . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tunjangan Jabatan</label>
                        <input type="number" maxlength="8" step="1" class="form-control" value="" name="eselon_tunjangan" id="edit_tunjangan" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Batas Usia Pensiun</label>
                        <input type="number" maxlength="2" step="1" class="form-control" value="" name="eselon_usia_pensiun" id="edit_pensiun" autocomplete="off">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script>
    function edit(id, nama,awal, akhir,tunjangan,pensiun) {
        $('#edit_kode').val(id);
        $('#edit_nama').val(nama);
        $('#edit_awal').val(awal).change();
        $('#edit_akhir').val(akhir).change();
        $('#edit_tunjangan').val(tunjangan);
        $('#edit_pensiun').val(pensiun);
    }
</script>