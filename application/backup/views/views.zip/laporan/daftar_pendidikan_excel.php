<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=daftar_pendidikan.xls");  //File name extension was wrong
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private",false);
 echo tableBuilder($result,NULL,'excel','example1');
?>
