<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="contact" class="content bg-silver-lighter" data-scrollview="true"  style="padding-top: 6rem;">
			<!-- begin container -->
			<div class="container">
				<h2 class="content-title">Hubungi Kami</h2>
<!-- 				<p class="content-desc">
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consectetur eros dolor,<br>
					sed bibendum turpis luctus eget
				</p> -->
				<!-- begin row -->
				<div class="row">
					<!-- begin col-6 -->
					<div class="col-lg-6 fadeInLeft contentAnimated finishAnimated" data-animation="true" data-animation-type="fadeInLeft">
<!-- 						<h3>If you have a project you would like to discuss, get in touch with us.</h3>
						<p>
							Morbi interdum mollis sapien. Sed ac risus. Phasellus lacinia, magna a ullamcorper laoreet, lectus arcu pulvinar risus, vitae facilisis libero dolor a purus.
						</p> -->
						<p>
							<strong>Pemerintah Kabupaten Sanggau<br>
                            Badan Kepegawaian dan Pengembangan Sumber Daya Manusia</strong><br>
							Jln KH. Dewantara No 35 Sanggau <br>
							Kalimantan Barat, 78512<br>
                         
						</p>
						<p>
							<span class="phone">( 0564 ) 21193 </span><br>
							<a href="mailto:bkpsdm@sanggau.go.id" class="text-primary">bkpsdm@mail.sanggau.go.id</a>
						</p>
					</div>
					<!-- end col-6 -->
					<!-- begin col-6 -->
					<div class="col-lg-6 form-col fadeInRight contentAnimated finishAnimated" data-animation="true" data-animation-type="fadeInRight">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.809003267256!2d110.59710020000001!3d0.1238229!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31fd8e14efab2843%3A0x89521a61406d0e44!2sJl.%20KH%20Dewantara%20No.35%2C%20Ilir%20Kota%2C%20Kec.%20Kapuas%2C%20Kabupaten%20Sanggau%2C%20Kalimantan%20Barat%2078516!5e0!3m2!1sid!2sid!4v1660207049018!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					</div>
					<!-- end col-6 -->
				</div>
				<!-- end row -->
			</div>
			<!-- end container -->
		</div>