<div class="content-wrapper">               

    <section class="content-header">
        <h1>
            Pegawai tidak ditemukan
        </h1>
    </section>


    <section class="content">
        

        <div class="row">
            <div class="col-md-12">
                <div class="box">

                    <div class="box-header with-border">
                        <h3 class="box-title">Pegawai tidak ditemukan</h3>
                    </div>

                    <div class="box-body table-responsive">

                    </div>
                </div>
            </div>



    </section>
</div>