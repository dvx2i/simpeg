<div class="content-wrapper">               

    <section class="content-header">
        <h1>
            Homepage Admin BPKAD
        </h1>
    </section>


    <section class="content">
        <?php /*
        <div class="row">
            <div class="col-lg-3 col-xs-6">

                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>
                            <?= $jml_struktural ?>
                        </h3>
                        <p>
                            Struktural
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion-clipboard"></i>
                    </div>
                    <a href="<?php echo base_url(); ?>" class="small-box-footer">
                        View <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-blue">
                    <div class="inner">
                        <h3>
                            <?= $jml_jft ?>
                        </h3>
                        <p>
                            Fungsional Tertentu
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion-clipboard"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        View <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>
                            <?= $jml_jfu ?>
                        </h3>
                        <p>
                            Fungsional Umum
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion-clipboard"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        View <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3>
                            <?= $jml_naban ?>
                        </h3>
                        <p>
                            Lainnya
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion-clipboard"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        View <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>
        */ ?>

        <div class="row">
            <div class="col-md-12">
                <div class="box">

                    <div class="box-header with-border">
                        <h3 class="box-title"></h3>
                    </div>

                    <div class="box-body table-responsive">

                    </div>
                </div>
            </div>



    </section>
</div>