<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>SIMPEG SANGGAU</title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- ================== BEGIN BASE CSS STYLE ================== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <link href="<?= base_url('assets/publik') ?>/css/one-page-parallax/app.min.css" rel="stylesheet" />
    <!-- ================== END BASE CSS STYLE ================== -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/font-awesome/css/font-awesome.min.css">


</head>

<body style="min-height: 100vh;
  position: relative;
  margin: 0;" data-spy="scroll" data-target="#header" data-offset="51">
    <!-- begin #page-container -->
    <div id="page-container" class="fade">
        <!-- begin #header -->
        <div id="header" class="header navbar navbar-default navbar-fixed-top navbar-expand-lg">
            <!-- begin container -->
            <div class="container">
                <!-- begin navbar-brand -->
                <a href="index.html" class="navbar-brand">
                    <img src="<?= base_url('assets/publik') ?>/img/logo-simpeg.png" alt="">
                </a>
                <!-- end navbar-brand -->
                <!-- begin navbar-toggle -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- end navbar-toggle -->
                <!-- begin navbar-collapse -->
                <div class="collapse navbar-collapse" id="header-navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?= site_url('Home') ?>">HOME</a>
                        </li>
                        <!-- <li class="nav-item"><a class="nav-link" href="#contact">TENTANG KAMI</a></li> -->
                        <?php if (empty($this->session->userdata('login'))) : ?>
                            <li class="nav-item"><a class="nav-link" href="<?= site_url('Akun') ?>">LOGIN</a></li>
                        <?php endif ?>
                        <?php if (!empty($this->session->userdata('login'))) : ?>
                            <li class="nav-item"><a class="nav-link" href="<?= site_url() ?>">ADMIN</a></li>
                        <?php endif ?>
                    </ul>
                </div>
                <!-- end navbar-collapse -->
            </div>
            <!-- end container -->
        </div>
        <!-- end #header -->

        <!-- //content  -->
        <?= $content ?>

        <!-- begin #footer -->
        <!-- <div id="footer" class="footer" style="padding-top: 6rem;">
            <center>
                &copy; Copyright Color Admin 2019 <br />
            </center>
        </div> -->
        <!-- end #footer -->


    </div>
    <!-- end #page-container -->

    <!-- ================== BEGIN BASE JS ================== -->
    <script src="<?= base_url('assets/publik') ?>/js/one-page-parallax/app.min.js"></script>
    <!-- ================== END BASE JS ================== -->
</body>

</html>