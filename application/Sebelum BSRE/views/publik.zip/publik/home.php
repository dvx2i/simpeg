<!-- begin #quote -->
<div id="quote" class="content" data-scrollview="true" style="background-color:#f1f3f4;">
    <!-- begin content-bg -->
    <!-- <div class="content-bg" style="background-image: url(<?= base_url('assets/publik') ?>/img/bg/bg-quote.jpg)"
				data-paroller-factor="0.5"
				data-paroller-factor-md="0.01"
				data-paroller-factor-xs="0.01">
			</div> -->
    <div class="content-bg" data-paroller-factor="0.5" data-paroller-factor-md="0.01" data-paroller-factor-xs="0.01">
    </div>
    <!-- end content-bg -->
    <!-- begin container -->
    <div class="container" data-animation="true" data-animation-type="fadeInLeft">
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12 quote">&nbsp;</div>
            <div class="col-md-12 quote">
                <!-- <i class="fa fa-quote-left"></i> Passion leads to design, design leads to performance, <br />
						performance leads to <span class="text-primary">success</span>!  
						<i class="fa fa-quote-right"></i> -->
                <img height="100px" src="<?= base_url('assets/publik') ?>/img/logo-simpeg.png" alt="">
                <!-- <small>simpeg.sanggau.go.id</small> -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>
<!-- end #quote -->


<!-- begin #pricing -->
<div id="price" class="content" data-scrollview="true">
    <!-- begin container -->
    <div class="container">
        <!-- <h2 class="content-title">Informasi</h2> -->
        <!-- <p class="content-desc">
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consectetur eros dolor,<br />
					sed bibendum turpis luctus eget
				</p> -->
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">Grafik PNS Berdasarkan Pendidikan (<?= bulan_indo()[$bulan] . '-' . $tahun ?>)</div>
                    <div style="">
                        <div class="card-body">
                            <div id="chart_pendidikan"></div>
                            <center>
                                <a href="<?= site_url('publik/PegawaiPendidikan') ?>" class="btn btn-grey">Selengkapnya</a>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">Grafik PNS Berdasarkan Jenis Kelamin (<?= bulan_indo()[$bulan] . '-' . $tahun ?>)</div>
                    <div style="">
                        <div class="card-body">
                            <div id="chart_jk"></div>
                            <center>
                                <a href="<?= site_url('publik/PegawaiJk') ?>" class="btn btn-grey">Selengkapnya</a>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        &nbsp;
        <div class="row">
            <div class="col-lg-6 offset-lg-3 ">
                <div class="card">
                    <div class="card-header">Grafik PNS Berdasarkan Golongan (<?= bulan_indo()[$bulan] . '-' . $tahun ?>)</div>
                    <div style="">
                        <div class="card-body">
                            <div id="chart_golru"></div>
                            <center>
                                <a href="<?= site_url('publik/PegawaiGolru') ?>" class="btn btn-grey">Selengkapnya</a>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- end container -->
</div>
<!-- end #pricing -->

<!-- jQuery 3 -->

<script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>

<!-- jQuery UI 1.11.4 -->

<script src="<?php echo base_url(); ?>assets/bower_components/jquery-ui/jquery-ui.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/TableToExcel/jquery.tableToExcel.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/highcharts.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/highcharts-3d.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/modules/data.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/modules/drilldown.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/modules/exporting.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/modules/export-data.js"></script>
<script src="<?= base_url() ?>assets/plugins/highcharts/modules/accessibility.js"></script>

<script>
    // console.log(Highcharts.char

    colChart1 = {
        chart: {
            type: 'column',
            // inverted: true,
            height: 400,
            options3d: {
                enabled: false,
                alpha: 15,
                beta: 15,
                depth: 50,
                viewDistance: 25
            }
        },
        title: {
            text: 'Jumlah PNS Menurut Pendidikan  <?= $unit != null ? $unit : ''; ?>'
        },
        subtitle: {
            text: 'simpeg.sanggau.go.id</a>'
        },
        xAxis: {
            type: 'category',
        },
        yAxis: {
            title: {
                text: 'Total Pegawai'
            }

        },
        legend: {
            enabled: true
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: false,
                    // format: '{point.y:.1f}'
                }
            }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> <br/>'
        },
        series: [{
            name: 'Laki-laki & Perempuan',
            type: 'column',
            color: '#84c31e',
            data: [

                <?php foreach ($rekap_pendidikan->result_array() as $key) : ?> {
                        name: "<?= $key['pendidikan'] ?>",
                        y: <?= $key['jumlah'] ?>,
                        drilldown: false
                    },
                <?php endforeach; ?>
            ]
        }]
    };

    colChart2 = {
        chart: {
            type: 'column',
            // inverted: true,
            height: 400,
            options3d: {
                enabled: false,
                alpha: 15,
                beta: 15,
                depth: 50,
                viewDistance: 25
            }
        },
        title: {
            text: 'Jumlah PNS Menurut Golongan  <?= $unit != null ? $unit : ''; ?>'
        },
        subtitle: {
            text: 'simpeg.sanggau.go.id</a>'
        },
        xAxis: {
            type: 'category',
        },
        yAxis: {
            title: {
                text: 'Total Pegawai'
            }

        },
        legend: {
            enabled: true
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: false,
                    // format: '{point.y:.1f}'
                }
            }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> <br/>'
        },
        series: [{
            name: 'Laki-laki & Perempuan',
            type: 'column',
            color: '#84c31e',
            data: [

                <?php foreach ($rekap_golru->result_array() as $key) : ?> {
                        name: "<?= $key['golru'] ?>",
                        y: <?= $key['jumlah'] ?>,
                        drilldown: false
                    },
                <?php endforeach; ?>
            ]
        }]
    };

    colChart3 = {
        chart: {
            type: 'pie',
            // inverted: true,
            height: 400,
            options3d: {
                enabled: true,
                alpha: 45,
                // beta: 0
            }
        },
        title: {
            text: 'Jumlah PNS Menurut Jenis Kelamin <?= $unit != null ? $unit : ''; ?>'
        },
        subtitle: {
            text: 'simpeg.sanggau.go.id</a>'
        },
        xAxis: {
            type: 'category',
        },
        yAxis: {
            title: {
                text: 'Total Pegawai'
            }

        },
        legend: {
            enabled: true
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    // format: '{point.y:.1f}'
                }
            },
            pie: {
                innerSize: 80,
                depth: 45,
                colors: ['#0a00fb',
                    '#fe7101'

                ],
            }

        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> <br/>'
        },
        series: [{
            name: 'Laki-laki & Perempuan',
            data: [

                <?php foreach ($rekap_jk->result_array() as $key) : ?> {
                        name: "<?= $key['jk'] ?>",
                        y: <?= $key['jumlah'] ?>,
                        drilldown: false
                    },
                <?php endforeach; ?>
            ]
        }]
    };

    // create the chart
    $('#chart_jk').highcharts($.extend(true, {}, colChart3));
    $('#chart_pendidikan').highcharts($.extend(true, {}, colChart1));
    $('#chart_golru').highcharts($.extend(true, {}, colChart2));
</script>