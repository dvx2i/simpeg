<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pengajuan extends MY_Controller
{

    function __construct()
    {
        parent::__construct();

        $this->load->model(array('m_home', 'ref_jenis_cuti', 'ref_berkas_cuti', 'm_pegawai_cuti_online', 'm_pegawai'));
    }


    function index()
    {
        $this->load->helper('text');
        date_default_timezone_set('Asia/Jakarta');
        $data['result'] = $this->m_pegawai_cuti_online->get_cuti_by_nip(array('pegawai_nip' => $this->session->userdata('login')['nip']));
        $data['no_permohonan'] = "";
        $data['berkas'] = $this->ref_berkas_cuti->get_all();

        if(!empty($this->session->userdata('no_permohonan'))){
            $data['no_permohonan'] = $this->session->userdata('no_permohonan');
        }

        $this->session->unset_userdata('no_permohonan');
        $data["content"] = $this->load->view('cuti/home', $data, TRUE);
        $this->load->view('publik/template', $data);
    }
    
    function create()
    {
        $this->load->helper('text');
        date_default_timezone_set('Asia/Jakarta');
        
        $data['jenis_cuti'] = $this->ref_jenis_cuti->get_all();
        
        $session = $this->session->userdata('login');
        $pegawai = $this->m_pegawai->get_row($session['nip']);
        $data['jenkel_id'] = $pegawai->pegawai_jenkel_id;
        $data['action'] = site_url('cuti/Pengajuan/create_action');
        $data['nama'] = $session['fullname'];
        $data['nip']  = $session['nip'];
        $data['pegawaicuti_id']  = set_value('pegawaicuti_id');
        $data['jeniscuti_id']  = set_value('jeniscuti_id');
        $data['cuti_mulai']  = set_value('cuti_mulai');
        $data['cuti_selesai']  = set_value('cuti_selesai');
        $data['keterangan']  = set_value('keterangan');
        $data['jumlah_hari']  = set_value('jumlah_hari');
        $data['tahun']  = set_value('tahun');
        $data['berkas'] = $this->ref_berkas_cuti->get_all();

        $data["content"] = $this->load->view('cuti/form', $data, TRUE);
        $this->load->view('publik/template', $data);
    }
    
    function create_action()
    {
        date_default_timezone_set('Asia/Jakarta');
        $data['pegawaicuti_pegawai_nip'] = $this->session->userdata('login')['nip'];
        $data['pegawaicuti_jeniscuti_id'] = $this->input->post('jeniscuti_id');
        $data['pegawaicuti_lama_cuti_mulai'] = y_m_d($this->input->post('cuti_mulai'));
        $data['pegawaicuti_lama_cuti_selesai'] = y_m_d($this->input->post('cuti_selesai'));
        $data['pegawaicuti_jumlah_hari'] = $this->input->post('jumlah_hari');
        $data['pegawaicuti_status_permohonan'] = '1';
        $data['pegawaicuti_keterangan'] = $this->input->post('keterangan');
        $data['insert_user_id'] = $this->session->userdata('login')['user_id'];
        $data['pegawaicuti_no_permohonan'] = $this->m_pegawai_cuti_online->get_no_permohonan();
        $data['pegawaicuti_tahun'] = '';
        $tahuns = $this->input->post('tahun');

        foreach($tahuns as $tahun) {
            $data['pegawaicuti_tahun'] .= $tahun.',';
        }
        $data['pegawaicuti_tahun'] .= '.'; // tambah . di akhir biar gampang nampilinnya tanpa , di akhir

        $this->session->set_userdata('no_permohonan', $data['pegawaicuti_no_permohonan']);

        $insert_id = $this->m_pegawai_cuti_online->insert_row($data);
        
        if (!empty($insert_id)) {

            $berkas = $this->ref_berkas_cuti->get_all();

                // $fileExt = pathinfo($_FILES["berkas"]["name"], PATHINFO_EXTENSION);
                // die($fileExt);

                $dir = "assets/files/cuti";
                $config['upload_path']    = $dir;
                $config['allowed_types']  = 'jpg|jpeg|png|pdf';
                $config['overwrite']      = TRUE;
                $config['file_ext_tolower'] = TRUE;
                $config['max_size']     = 2084;
                // $config['encrypt_name'] = TRUE;
                // die($config['file_name']);

                foreach ($berkas->result_array() as $item) {

                    $id = $item['berkas_id'];
                    // print_r($_FILES["berkas_" . $id]["name"]); die;
                    $config['file_name'] = md5($id) . '_' . date('H_i_s');

                    if ($_FILES["berkas_" . $id]["name"] != NULL) {
                        $this->load->library('upload');

                        $this->upload->initialize($config);

                        $fieldname = "berkas_" . $id;

                        if ($this->upload->do_upload($fieldname)) {

                            $upload = array();
                            $upload = $this->upload->data();

                            $data_file = array(
                                'cuti_id' => $insert_id,
                                'url_file' => $upload['file_name'],
                                'berkas_id' => $id
                            );
                            $this->m_pegawai_cuti_online->save_file($data_file);
                        } else {
                            $this->session->set_flashdata('message', alert_show('danger', "Upload File Gagal"));
                            redirect('mutasi/Pengajuan/add');
                        }
                    }else{
                        $this->session->set_flashdata('message', alert_show('danger', "Berkas Tidak Lengkap"));
                        redirect('mutasi/Pengajuan/add');
                    }
                }

            $this->session->set_flashdata('message', "success");
        } else {
            $this->session->set_flashdata('message', "fail");
        }
        redirect('cuti/Pengajuan');
    }
    
    function update($id)
    {
        $this->load->helper('text');
        date_default_timezone_set('Asia/Jakarta');
        
        $data['jenis_cuti'] = $this->ref_jenis_cuti->get_all();
        $row = $this->m_pegawai_cuti_online->get_by_no($id);
        
        $session = $this->session->userdata('login');
        if($row->pegawaicuti_pegawai_nip == $session['nip']) {
            
            $data['pegawai'] = $this->m_pegawai->get_row($session['nip']);
            $data['action'] = site_url('cuti/Pengajuan/update_action/'.$id);
            $data['nama'] = $session['fullname'];
            $data['nip']  = $session['nip'];
            $data['pegawaicuti_id']  = set_value('pegawaicuti_id', $row->pegawaicuti_id);
            $data['jeniscuti_id']  = set_value('jeniscuti_id', $row->pegawaicuti_jeniscuti_id);
            $data['cuti_mulai']  = set_value('cuti_mulai', $row->pegawaicuti_lama_cuti_mulai);
            $data['cuti_selesai']  = set_value('cuti_selesai', $row->pegawaicuti_lama_cuti_selesai);
            $data['keterangan']  = set_value('keterangan', $row->pegawaicuti_keterangan);
            $data['jumlah_hari']  = set_value('jumlah_hari', $row->pegawaicuti_jumlah_hari);
            $data['berkas'] = $this->ref_berkas_cuti->get_all();
            $data['berkas_cuti'] = $this->m_pegawai_cuti_online->getBerkasByPermohonan($row->pegawaicuti_id);

            $tahuns = explode(',',$row->pegawaicuti_tahun);
            $data['tahun'] = $tahuns;

            $data["content"] = $this->load->view('cuti/form', $data, TRUE);
            $this->load->view('publik/template', $data);
        }else{
            redirect('cuti/Pengajuan');
        }
    }
    
    function update_action()
    {
        date_default_timezone_set('Asia/Jakarta');
        $id = $this->input->post('pegawaicuti_id');
        $session = $this->session->userdata('login');
        $row = $this->m_pegawai_cuti_online->get_by_id($id);
        if ($row) {

        $data['pegawaicuti_jeniscuti_id'] = $this->input->post('jeniscuti_id');
        $data['pegawaicuti_lama_cuti_mulai'] = y_m_d($this->input->post('cuti_mulai'));
        $data['pegawaicuti_lama_cuti_selesai'] = y_m_d($this->input->post('cuti_selesai'));
        $data['pegawaicuti_jumlah_hari'] = $this->input->post('jumlah_hari');
        $data['pegawaicuti_status_permohonan'] = '1';
        $data['pegawaicuti_keterangan'] = $this->input->post('keterangan');
        $data['pegawaicuti_tahun'] = '';
        $tahuns = $this->input->post('tahun');

        foreach($tahuns as $tahun) {
            $data['pegawaicuti_tahun'] .= $tahun.',';
        }
        $data['pegawaicuti_tahun'] .= '.'; // tambah . di akhir biar gampang nampilinnya tanpa , di akhir

        $update = $this->m_pegawai_cuti_online->update($data, $id);
        
        if (!empty($update)) {

            $berkas = $this->ref_berkas_cuti->get_all();

                // $fileExt = pathinfo($_FILES["berkas"]["name"], PATHINFO_EXTENSION);
                // die($fileExt);

                $dir = "assets/files/cuti";
                $config['upload_path']    = $dir;
                $config['allowed_types']  = 'jpg|jpeg|png|pdf';
                $config['overwrite']      = TRUE;
                $config['file_ext_tolower'] = TRUE;
                $config['max_size']     = 2084;
                // $config['encrypt_name'] = TRUE;
                // die($config['file_name']);

                foreach ($berkas->result_array() as $item) {

                    $id_berkas = $item['berkas_id'];
                    // print_r($_FILES["berkas_" . $id]["name"]); die;
                    $config['file_name'] = md5($id) . '_' . date('H_i_s');

                    if ($_FILES["berkas_" . $id]["name"] != NULL) {
                        $this->load->library('upload');

                        $this->upload->initialize($config);

                        $fieldname = "berkas_" . $id;

                        if ($this->upload->do_upload($fieldname)) {
                            
                            $this->m_pegawai_cuti_online->delete_file($id_berkas,$id); //delete file yg sdh ada

                            $upload = array();
                            $upload = $this->upload->data();

                            $data_file = array(
                                'cuti_id' => $id,
                                'url_file' => $upload['file_name'],
                                'berkas_id' => $id
                            );
                            $this->m_pegawai_cuti_online->save_file($data_file);
                        } else {
                            $this->session->set_flashdata('message', alert_show('danger', "Upload File Gagal"));
                            redirect('cuti/Pengajuan/update/'.$row->pegawaicuti_no_permohonan);
                        }
                    }
                }

            $this->session->set_flashdata('message', "success");
        } else {
            $this->session->set_flashdata('message', "fail");
        }
        redirect('cuti/Pengajuan');
    }
        else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect('cuti/Pengajuan');
        }
    }
    
    public function delete($id)
    {
        $row = $this->m_pegawai_cuti_online->get_by_no($id);
        
        $session = $this->session->userdata('login');
        if($row->pegawaicuti_pegawai_nip == $session['nip']) {
            $simpan = $this->m_pegawai_cuti_online->delete($id);
            if (!empty($simpan)) {
                    $this->session->set_flashdata('message', alert_show('success', "Berhasil Terhapus"));
            } else {
                    $this->session->set_flashdata('message', alert_show('danger', "Gagal Terhapus"));
            }
            redirect('cuti/Pengajuan');
        }else{
            redirect('cuti/Pengajuan');
        }
    }
}