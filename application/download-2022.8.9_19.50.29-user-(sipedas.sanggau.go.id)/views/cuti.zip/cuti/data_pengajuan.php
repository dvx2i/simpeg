<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/tracker/tracker.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/date-text/jquery.datetextentry.css">

<style>
  .form-control-plaintext {
    display: block;
    width: 100%;
    padding-top: 0.375rem;
    padding-bottom: 0.375rem;
    margin-bottom: 0;
    line-height: 1.5;
    color: #333;
    background-color: transparent;
    border: solid transparent;
    border-width: 2px 0;
  }
</style>
<div class="content-wrapper">

  <section class="content-header">
    <?php echo $this->session->flashdata('message'); ?>
    <h1>
      Pengajuan Cuti Online
    </h1>
  </section>


  <section class="content">
    <!-- <a href="<?= site_url('mutasi/Pengajuan/add') ?>" class="btn btn-primary" ><i class="fa fa-plus"></i> Pengajuan Baru</a>
        <br />
        <br /> -->
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
          </div>
          <div class="box-body table-responsive">
            <table id="mytable" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                  <th>No</th>
                  <th>No Permohonan</th>
                  <th>Status</th>
                  <th>NIP</th>
                  <th>Nama</th>
                  <th>Jenis Cuti</th>
                  <th>Tanggal Mulai</th>
                  <th>Tanggal Selesai</th>
                  <th>SI Cuti</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php /*
                                $no = 1;
                                foreach ($result->result() as $value) {
                                    ?>
                                    <tr>
                                        <td><?= $no ?></td>
                                        <td><?= $value->agama_nama ?></td>
                                        
                                        <td>
                                            <a href="#" class="btn btn-warning btn-sm" type="button" onclick="edit('<?= $value->agama_id ?>','<?= $value->agama_nama ?>')" data-toggle="modal" data-target="#modal-update"><i class="fa fa-edit"></i></a>
                                                <a href="<?= site_url('referensi/agama/delete/' . $value->agama_id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin menghapus data.?')"><i class="fa fa-trash-o fa-fw"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                    $no++;
                                }
                                */ ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>


<!-- The Modal -->
<div class="modal" id="myModal2">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Input Nomor Ijin Cuti</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <form action="<?= site_url('cuti/DataPengajuan/update/sk/') ?>" method="POST" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="row">
            <div class="col-md-6 form-group">
              <label for="">Nomor</label>
              <input type="text" name="nomor" id="nomor_sk" class="form-control">
              <input type="hidden" name="pegawaicuti_id" id="pegawaicutisk_id" value="">
            </div>
            <div class="col-md-6 form-group">
              <label for="">Tanggal</label>
              <input type="text" name="tanggal" id="tanggal_sk" class="form-control dateEntry">
            </div>
            <!-- <div class="col-md-12 form-group">
							<label for="">Catatan</label>
							<textarea name="catatan" id="siswa_catatan" class="form-control" rows="5"></textarea>
						</div> -->
          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Simpan</button>
        </div>
      </form>

    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="verifModal" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable  modal-lg">
    <div class="modal-content">
      <div class="modal-body tracking" style="min-height: 99px;">

      </div>
      <div class="modal-body">
        <form class="form form-horizontal">
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Status Permohonan:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext " id="status_permohonan" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-sm-4 col-form-label">No Permohonan:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="no_permohonan" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">NIP:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="nip" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Nama:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="nama" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Jenis Cuti:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="jenis_cuti" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Tanggal Mulai:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="tanggal_mulai" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Tanggal Selesai:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="tanggal_selesai" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Keterangan:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="keterangan" value="">
            </div>
          </div>
          <?php for ($i = 0; $i < count($berkas->result_array()); $i++) : ?>
            <div class="form-group row">
              <label for="message-text" class="col-sm-4 col-form-label"></label>
              <div class="col-sm-8" id="formv<?= $i ?>">
              </div>
            </div>
          <?php endfor; ?>
        </form>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="pegawaicuti_id" value="">
        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
        <button data-toggle="modal" data-target="#myModal" class="btn btn-danger buttons-html5 btn-sm" type="button"><span><i class="fa fa-undo"></i> Tolak</span></button>
        <button type="button" id="btn-terima" class="btn btn-primary">Verifikasi</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="detailModal" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable  modal-lg">
    <div class="modal-content">
      <div class="modal-body tracking" style="min-height: 99px;">

      </div>
      <div class="modal-body">
        <form class="form form-horizontal">
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Status Permohonan:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext " id="status_permohonan_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-sm-4 col-form-label">No Permohonan:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="no_permohonan_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">NIP:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="nip_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Nama:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="nama_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Jenis Cuti:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="jenis_cuti_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Tanggal Mulai:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="tanggal_mulai_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Tanggal Selesai:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="tanggal_selesai_detail" value="">
            </div>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-sm-4 col-form-label">Keterangan:</label>
            <div class="col-sm-8">
              <input type="text" readonly class="form-control-plaintext" id="keterangan_detail" value="">
            </div>
          </div>
          <?php for ($i = 0; $i < count($berkas->result_array()); $i++) : ?>
            <div class="form-group row">
              <label for="message-text" class="col-sm-4 col-form-label"></label>
              <div class="col-sm-8" id="form<?= $i ?>">
              </div>
            </div>
          <?php endfor; ?>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Kembali</button>
      </div>
    </div>
  </div>
</div>


<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Tolak Permohonan</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="">
          <div class="row">
            <div class="col-md-12">
              <label for="">Keterangan</label>
              <textarea name="keterangan" id="keterangan_tolak" class="form-control" rows="5"></textarea>
            </div>
          </div>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button id="btn-tolak" type="button" class="btn btn-danger" data-dismiss="modal">Tolak</button>
      </div>

    </div>
  </div>
</div>

<link rel="stylesheet" href="<?= base_url() ?>assets/sweetalert/sweetalert2.css">
<script src="<?= base_url() ?>assets/sweetalert/sweetalert2.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/date-text/jquery.datetextentry.js"></script>

<script>
  $('.dateEntry').datetextentry({
    show_tooltips: false,
    errorbox_x: -135,
    errorbox_y: 28
  });

  function verif(v) {

    $("#verifModal").find(".tracking").html('');

    $.ajax({
      url: '<?= site_url('pegawai/PegawaiAjax/getPegawaiCutiOnlineById') ?>',
      type: "POST",
      data: {
        ajax: '1',
        id: v
      },
      dataType: "json",
      async: true,
      success: function(data) {
        $('#no_permohonan').val(data.pegawaicuti_no_permohonan);
        $('#nip').val(data.pegawaicuti_pegawai_nip);
        $('#nama').val(data.pegawai_nama);
        $('#jenis_cuti').val(data.jenis_cuti_nama);
        $('#tanggal_mulai').val(data.pegawaicuti_lama_cuti_mulai);
        $('#tanggal_selesai').val(data.pegawaicuti_lama_cuti_selesai);
        $('#keterangan').val(data.pegawaicuti_keterangan);
        $('#status_permohonan').val(data.status_nama);
        $('#pegawaicuti_id').val(data.pegawaicuti_id);
        // $('#formadd').attr('action', '<?= site_url('pegawai/PegawaiCuti/update') ?>');

        var status_permohonan = data.pegawaicuti_status_permohonan;
        var class1 = "todo";
        var class2 = "todo";
        var class3 = "todo";
        var class4 = "todo";

        if (status_permohonan == '3') {
          var class1 = "done";
        }
        if (status_permohonan == '1') {
          var class1 = "done";
          var class2 = "done";
        }
        if (status_permohonan == '2') {
          var class1 = "done";
          var class2 = "done";
          var class3 = "done";
        }
        if (status_permohonan == '4') {
          var class1 = "done";
          var class2 = "done";
          var class3 = "done";
          var class4 = "done";
        }


        var progres = '<ol class="track-progress"> ' +
          '<li class="' + class1 + '"> ' +
          '<em>1</em> ' +
          '<span>Pengajuan</span> ' +
          '</li> ' +
          '<li class="' + class2 + '"> ' +
          '<em>2</em> ' +
          '<span>Verifikasi</span> ' +
          '</li> ' +
          '<li class="' + class3 + '"> ' +
          ' <em>3</em> ' +
          '<span>Diproses</span> ' +
          '</li> ' +
          '<li class="' + class4 + '"> ' +
          '<em>4</em> ' +
          '<span>Disetujui</span> ' +
          '</li> ' +
          '</ol>';


        $("#verifModal").find(".tracking").append(progres);
      }
    });


    $.ajax({
      url: '<?= site_url('pegawai/PegawaiAjax/getPegawaiCutiOnlineBerkasById') ?>',
      type: "POST",
      data: {
        ajax: '1',
        id: v
      },
      dataType: "json",
      async: true,
      success: function(data) {
        $.each(data, function(i, item) {
          var html = ' <a href="<?= base_url("assets/files/cuti/") ?> ' + item.url_file + '" class="btn btn-default" target="_blank"><i class="fa fa-download"></i> <small>Unduh ' + item.berkas_nama + '</small></a>';
          $('#formv' + i).html(html);
        });
      }
    });

    $('#verifModal').modal('show')

  }

  function detail(v) {

    $("#detailModal").find(".tracking").html('');

    $.ajax({
      url: '<?= site_url('pegawai/PegawaiAjax/getPegawaiCutiOnlineById') ?>',
      type: "POST",
      data: {
        ajax: '1',
        id: v
      },
      dataType: "json",
      async: true,
      success: function(data) {
        $('#no_permohonan_detail').val(data.pegawaicuti_no_permohonan);
        $('#nip_detail').val(data.pegawaicuti_pegawai_nip);
        $('#nama_detail').val(data.pegawai_nama);
        $('#jenis_cuti_detail').val(data.jenis_cuti_nama);
        $('#tanggal_mulai_detail').val(data.pegawaicuti_lama_cuti_mulai);
        $('#tanggal_selesai_detail').val(data.pegawaicuti_lama_cuti_selesai);
        $('#keterangan_detail').val(data.pegawaicuti_keterangan);
        $('#status_permohonan_detail').val(data.status_nama);
        // $('#pegawaicuti_pejabat').val(data.pegawaicuti_pejabat).change();
        // $('#formadd').attr('action', '<?= site_url('pegawai/PegawaiCuti/update') ?>');

        var status_permohonan = data.pegawaicuti_status_permohonan;
        var class1 = "todo";
        var class2 = "todo";
        var class3 = "todo";
        var class4 = "todo";

        if (status_permohonan == '3') {
          var class1 = "done";
        }
        if (status_permohonan == '1') {
          var class1 = "done";
          var class2 = "done";
        }
        if (status_permohonan == '2') {
          var class1 = "done";
          var class2 = "done";
          var class3 = "done";
        }
        if (status_permohonan == '4') {
          var class1 = "done";
          var class2 = "done";
          var class3 = "done";
          var class4 = "done";
        }


        var progres = '<ol class="track-progress"> ' +
          '<li class="' + class1 + '"> ' +
          '<em>1</em> ' +
          '<span>Pengajuan</span> ' +
          '</li> ' +
          '<li class="' + class2 + '"> ' +
          '<em>2</em> ' +
          '<span>Verifikasi</span> ' +
          '</li> ' +
          '<li class="' + class3 + '"> ' +
          ' <em>3</em> ' +
          '<span>Diproses</span> ' +
          '</li> ' +
          '<li class="' + class4 + '"> ' +
          '<em>4</em> ' +
          '<span>Disetujui</span> ' +
          '</li> ' +
          '</ol>';


        $("#detailModal").find(".tracking").append(progres);
      }
    });

    $.ajax({
      url: '<?= site_url('pegawai/PegawaiAjax/getPegawaiCutiOnlineBerkasById') ?>',
      type: "POST",
      data: {
        ajax: '1',
        id: v
      },
      dataType: "json",
      async: true,
      success: function(data) {
        $.each(data, function(i, item) {
          var html = ' <a href="<?= base_url("assets/files/cuti/") ?> ' + item.url_file + '" class="btn btn-default" target="_blank"><i class="fa fa-download"></i> <small>Unduh ' + item.berkas_nama + '</small></a>';
          $('#form' + i).html(html);
        });
      }
    });

    $('#detailModal').modal('show')

  }

  function sk(v) {
    $('#pegawaicutisk_id').val(v);
    $('#myModal2').modal('show');

  }
  $(document).ready(function() {
    $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings) {
      return {
        "iStart": oSettings._iDisplayStart,
        "iEnd": oSettings.fnDisplayEnd(),
        "iLength": oSettings._iDisplayLength,
        "iTotal": oSettings.fnRecordsTotal(),
        "iFilteredTotal": oSettings.fnRecordsDisplay(),
        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
      };
    };

    var t = $("#mytable").dataTable({
      initComplete: function() {
        var api = this.api();
        $('#mytable_filter input')
          .off('.DT')
          .on('keyup.DT', function(e) {
            if (e.keyCode == 13) {
              api.search(this.value).draw();
            }
          });
      },
      scrollX: true,
      oLanguage: {
        sEmptyTable: "Tidak ada data yang tersedia pada tabel ini",
        sProcessing: "Sedang memproses...",
        sLengthMenu: "Tampilkan _MENU_ entri",
        sZeroRecords: "Tidak ditemukan data yang sesuai",
        sInfo: "Menampilkan _START_ sampai _END_ dari _TOTAL_ entri",
        sInfoEmpty: "Menampilkan 0 sampai 0 dari 0 entri",
        sInfoFiltered: "(disaring dari _MAX_ entri keseluruhan)",
        sInfoPostFix: "",
        sSearch: "Cari:",
        sUrl: "",
        oPaginate: {
          sFirst: "Pertama",
          sPrevious: "Sebelumnya",
          sNext: "Selanjutnya",
          sLast: "Terakhir"
        }
      },
      processing: true,
      serverSide: true,
      ajax: {
        "url": "DataPengajuan/json",
        "type": "POST",
        "data": function(data) {
          //   data.id_pemilik = $('#pemilik').val();
          //   data.id_pengguna = $('#id_pengguna').val();
          //   data.id_kuasa_pengguna = $('#id_kuasa_pengguna').val();
        }
      },
      columns: [{
          "data": "pegawaicuti_id",
          // "orderable": false,
        }, {
          "data": "pegawaicuti_no_permohonan",
          // "orderable": false,
        },
        {
          "data": "pegawaicuti_status_permohonan"
        },
        {
          "data": "pegawaicuti_pegawai_nip"
        },
        {
          "data": "pegawai_nama"
        },
        {
          "data": "jenis_cuti_nama",
          "searchable": false
        },
        {
          "data": "pegawaicuti_lama_cuti_mulai"
        },
        {
          "data": "pegawaicuti_lama_cuti_selesai"
        },
        {
          "data": "file_sk",
          "searchable": false
        },
        {
          "data": "action",
          "orderable": false,
          "className": "text-center",
          'width': '15%'
        },
      ],
      order: [
        [0, 'desc']
      ],
      rowCallback: function(row, data, iDisplayIndex) {
        var info = this.fnPagingInfo();
        var page = info.iPage;
        var length = info.iLength;
        var index = page * length + (iDisplayIndex + 1);
        $('td:eq(0)', row).html(index);
        // if (data['status_validasi'] == '1') $('td', row).css('background-color', 'white');
        // else if (data['status_validasi'] == '2') $('td', row).css('background-color', 'ghostwhite');
        // else if (data['status_validasi'] == '3') $('td', row).css('background-color', '#F5B7B1  ');
      }
    });



    $('#btn-terima').click(function() {
      swal({

        title: "",
        text: "Verifikasi Permohonan?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya',
        cancelButtonText: 'Batalkan'
      }).then((result) => {
        if (result.value) {

          var keterangan = $('#keterangan').val();
          var pegawaicuti_id = $('#pegawaicuti_id').val();

          var form = "<form id='hidden-form' action='<?= site_url('cuti/DataPengajuan/update/verify') ?>' method='post'>";

          form += "<input type='hidden' name='keterangan' value='" + keterangan + "'/>";
          form += "<input type='hidden' name='pegawaicuti_id' value='" + pegawaicuti_id + "'/>";

          $(form + "</form>").appendTo($(document.body)).submit();

        } else {
          swal("Dibatalkan", "", "error");
        }
      })

    });


    $('#btn-tolak').click(function() {
      swal({
        title: "",
        text: "Tolak usulan mutasi",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: 'Ya',
        cancelButtonText: "Batal",
        closeOnConfirm: true,
        closeOnCancel: true
      }).then((result) => {
        if (result.value) {

          var keterangan = $('#keterangan_tolak').val();
          var pegawaicuti_id = $('#pegawaicuti_id').val();

          var form = "<form id='hidden-form' action='<?= site_url('cuti/DataPengajuan/update/reject') ?>' method='post' >";

          form += "<input type='hidden' name='keterangan' value='" + keterangan + "'/>";
          form += "<input type='hidden' name='pegawaicuti_id' value='" + pegawaicuti_id + "'/>";

          $(form + "</form>").appendTo($(document.body)).submit();
        } else {
          swal("Dibatalkan", "", "error");
        }
      })

    });


    // $('#btn-upload').click(function() {

    //   var frm = $('#form_permohonan');
    //   var formData = new FormData(frm[0]);

    //   $.ajax({
    //     type: "POST", // Method pengiriman data bisa dengan GET atau POST
    //     url: "<?= site_url('mutasi/DataPengajuan/update/sk/') ?>",
    //     dataType: "JSON",
    //     data: formData,
    //     processData: false,
    //     contentType: false,
    //     success: function(response) {
    //       location.reload();
    //     },
    //     error: function(xhr, ajaxOptions, thrownError) { // Ketika ada error
    //       swal(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
    //     }
    //   });
    // })

  });
</script>