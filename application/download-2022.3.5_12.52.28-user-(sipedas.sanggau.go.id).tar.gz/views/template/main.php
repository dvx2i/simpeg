<!DOCTYPE html>
<html>
<?=$head?>
<body class="hold-transition skin-red sidebar-mini">
<div >

  <?=$header?>
  <!-- Left side column. contains the logo and sidebar -->
  <?=$sidebar?>

  <!-- Content Wrapper. Contains page content -->
  <?=$content?>
  <!-- /.content-wrapper -->
  

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  
</div>
<!-- ./wrapper -->

<?=$footer?>
</body>
</html>
