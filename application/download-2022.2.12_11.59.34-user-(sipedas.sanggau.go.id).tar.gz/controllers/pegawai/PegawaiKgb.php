<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class PegawaiKgb extends MY_Controller {

    //variable
    var $view = 'pegawai/pegawai_kgb';     // file view
    var $redirect = 'pegawai/PegawaiKgb';     // redirect to here
    var $modul = 'Kenaikan Gaji Berkala';        // this modul or class name

    public function __construct() {
        parent::__construct();
        $this->load->model(array('m_pegawai_kgb'));
        $this->load->model(array('ref_unit'));
    }

    public function index() {
        $data['unit'] = $this->ref_unit->get_unit();
        $this->loadView($this->view,$data);
    }

    public function json()
    {
        header('Content-Type: application/json');
        echo $this->m_pegawai_kgb->json();
    }

    public function update() {
        //extrac post here and post primary key is id
        $session = $this->session->userdata('login');
        $nips = $this->input->post('nip');
        $array = implode("','",$nips);
        $pegawai = $this->m_pegawai_kgb->get_pegawai_gaji($array);
        // print_r($session['user_id']); die;
        foreach($pegawai->result() as $key) {
            $update = $this->m_pegawai_kgb->proses_kgb($key->pegawai_nip,$key->pegawai_pangkat_terakhir_id,$key->pangkat_golongan_text,$key->gaji_jumlah,$key->gaji_masa_kerja,$session['user_id']);
        }

        $this->session->set_flashdata('message', alert_show(array('success', "Proses Berhasil")));
        
        redirect($this->redirect);
    }

    public function delete($id) {
        $delete = $this->m_konversi->delete($id);
        if ($delete) {
            $this->session->set_flashdata('message', alert_show(array('success', "Delete " . $this->modul . " Berhasil")));
        } else {
            $this->session->set_flashdata('message', alert_show(array('danger', "Delete " . $this->modul . " Gagal")));
        }
        redirect($this->redirect);
    }

    public function excel() {
        $data['result'] = $this->m_konversi->get_all();
        $data['nama_file'] = date('Ymdhis') . '_' . $this->modul;
        $this->load->view('export/excel', $data);
    }

}
