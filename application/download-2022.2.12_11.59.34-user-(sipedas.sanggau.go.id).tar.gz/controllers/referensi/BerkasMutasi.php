<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Group
 *
 * @author Zanuar
 */
class BerkasMutasi extends MY_Controller {

    var $page = "referensi/berkas_mutasi";

    public function __construct() {
        parent::__construct();
        $this->load->model('ref_berkas_mutasi');
    }

    //put your code here

    public function index() {
        $data['result'] = $this->ref_berkas_mutasi->get_all();
        $this->loadView($this->page, $data);
    }

    public function update() {
        $id = $this->input->post('id');
        $data['berkas_nama'] = $this->input->post('nama');
        $data['berkas_urut'] = $this->input->post('urut');
        $update = $this->ref_berkas_mutasi->update($data, $id);
        if (!empty($update)) {
            $this->session->set_flashdata('message', alert_show('success', "Update Berhasil"));
        } else {
            alert_set('danger', "Update Gagal");
        }
        redirect('referensi/BerkasMutasi');
    }

    public function add() {
        $data['berkas_nama'] = $this->input->post('nama');
        $data['berkas_urut'] = $this->input->post('urut');
        $simpan = $this->ref_berkas_mutasi->insert($data);
        if (!empty($simpan)) {
            alert_set('success', "Tambah Berhasil");
        } else {
            alert_set('danger', "Tambah Gagal");
        }
        redirect('referensi/BerkasMutasi');
    }

    public function delete($id) {
        $simpan = $this->ref_berkas_mutasi->delete($id);
        if (!empty($simpan)) {
            alert_set('success', "Hapus Berhasil");
        } else {
            alert_set('danger', "Hapus Gagal");
        }
        redirect('referensi/BerkasMutasi');
    }

}
